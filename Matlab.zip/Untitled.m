disp('**************** Problem 6 ****************');
num_joints=7;

L1 = 340;
L2 = 400;
L3 = L2;
L4 = 126;
total = L1+L2+L3+L4;

fprintf('*** Part (a)');
M = [1,0,0,0; 0,1,0,0; 0,0,1,(L1+L2+L3+L4); 0,0,0,1]

S1 = [0 0 1 0 0 0]';
S2 = [1 0 0 0 L1 0]';
S3 = [0 0 1 0 0 0]';
S4 = [1 0 0 0 L1+L2 0]';
S5 = [0 0 1 0 0 0]';
S6 = [1 0 0 0 L1+L2+L3 0]';
S7 = [0 0 1 0 0 0]';
S = [S1, S2, S3, S4, S5, S6, S7];

B1 = [0 0 1 0 0 0]';
B2 = [1 0 0 0 -(L2+L3+L4) 0]';
B3 = [0 0 1 0 0 0]';
B4 = [1 0 0 0 -(L3+L4) 0]';
B5 = [0 0 1 0 0 0]';
B6 = [1 0 0 0 -L4 0]';
B7 = [0 0 1 0 0 0]';
B = [B1, B2, B3, B4, B5, B6, B7];

fprintf('*** Part (b)');
S

fprintf('*** Part (c)');
B

fprintf('*** Part (d-1)'); 
thetad = [0,90,0,-90,0,-90,0]';
theta = deg2rad(thetad);

% Both of the below should give the same answer (representing the screw
% axes in the space or end-effector frame). 
% End-effector position using the screw axes in the space frame
T = M;
for i=num_joints: -1: 1 % iterating backwards since M is post-multiplied in the space frame
    omega_bracket = VecToso3(S(:,i));
    Scv = S(4:end,i);
    star = (eye(3)*theta(i) + (1-cos(theta(i)))*omega_bracket + (theta(i) - sin(theta(i)))*omega_bracket^2)*Scv;
    T_i = [expm(omega_bracket*theta(i)), star; 0,0,0,1];
    T = T_i*T;
end  
T_space = T

% End-effector position using the screw axes in the end-effector frame 
T = M;
for i=1:num_joints % iterating forwared since M is pre-multiplied in the end-effector frame
    omega_bracket = VecToso3(B(:,i));
    Bcv = B(4:end,i);
    star = (eye(3)*theta(i) + (1-cos(theta(i)))*omega_bracket + (theta(i) - sin(theta(i)))*omega_bracket^2)*Bcv;
    T_i = [expm(omega_bracket*theta(i)), star; 0,0,0,1];
    T = T*T_i;
end  
T_body = T

fprintf('*** Part (d-1) using Matlab functions explicitly');
% Using the expm function explicitly for both
% Space frame end-effector position
T = M;
for i=num_joints: -1: 1
    S_bracket = VecTose3(S(:,i));
    T = expm(S_bracket*theta(i))*T;
end   
T_space2 = T

% End effector frame end-effector position
T = M;
for i=1:num_joints
    B_bracket = VecTose3(B(:,i));
    T = T*expm(B_bracket*theta(i));
end   
T_body2 = T

function so3mat = VecToso3(omg)
% Takes a 3-vector (angular velocity).
% Returns the skew symmetric matrix in so (3).
% Example Input:
% 
% clear; clc;
% omg = [1; 2; 3];
% so3mat = VecToso3(omg)
% 
% Output:
% so3mat =
%     0    -3     2
%     3     0    -1
%    -2     1     0

so3mat = [0, -omg(3), omg(2); omg(3), 0, -omg(1); -omg(2), omg(1), 0];
end
function se3mat = VecTose3(V)
% Takes a 6-vector (representing a spatial velocity).
% Returns the corresponding 4x4 se(3) matrix.
% Example Input:
% 
% clear; clc;
% V = [1; 2; 3; 4; 5; 6];
% se3mat = VecTose3(V)
% 
% Output:
% se3mat =
%     0    -3     2     4
%     3     0    -1     5
%    -2     1     0     6
%     0     0     0     0 

se3mat = [VecToso3(V(1: 3)), V(4: 6); 0, 0, 0, 0];
end
