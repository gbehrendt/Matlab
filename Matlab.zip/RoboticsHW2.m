%Problem 2
Tcb=[1/sqrt(2),0,1/sqrt(2),0;0,1,0,1;-1/sqrt(2),0,1/sqrt(2),0;0,0,0,1];
Rab=[1/sqrt(2),-1/sqrt(2),0;1/sqrt(2),1/sqrt(2),0;0,0,1]
p=[-1;0;1]
Rabt=Rab.';
B=-Rabt*p;
extra=[0,0,0,1];

Tba=[Rabt,B;extra];
Tca=Tcb*Tba

%Problem 3
shat=[0;0;1];
q=[3;0;0];
thetadot=1;
h=2;

omega=shat*thetadot;

A=cross(-shat,q);
B=h*shat*thetadot;

v=A+B;
S=[omega;v]

%Problem 6
omg=[0; 0; -2];
vb=[2; 1.4; 0];
Vb=[omg;vb] %Body Twist

Tsb=[-1 0 0 4;0 1 0 0.4;0 0 -1 0;0 0 0 1];
[Rsb,psb] = TransToRp(Tsb);
so3mat = VecToso3(omg);
AdtTsb = Adjoint(Tsb);

Vs=AdtTsb*Vb %Spacial Twist 


function [R, p] = TransToRp(T)
R = T(1: 3, 1: 3);
p = T(1: 3, 4);
end
function so3mat = VecToso3(omg)
so3mat = [0, -omg(3), omg(2); omg(3), 0, -omg(1); -omg(2), omg(1), 0];
end
function AdT = Adjoint(T)
[R, p] = TransToRp(T);
AdT = [R, zeros(3); VecToso3(p) * R, R];
end

