%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name: Gabe Behrendt
% Date: November 30, 2016
% Program Name: findsailors.m
% Program Description: A robotic ship is searching for missing sailors The 
% ship will do a random search strategy, and its path will be recorded with
% a line following it. The ship is allowed 400 fuel units and must return 
% to "home base" when it runs out of fuel. This program will run until 
% all three randomly placed sailors are found by the robotic ship.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function findsailors()
cla reset %clears graphics
clc; % clear command window
clear; % clear all variables
hold; % This keeps the figure window open
axis([0, 40, 0, 40]) %set the plot area to 0 to 40 (x-axis), and 0 to 40 (y)

%Declaring start points and variables
xsailor=randi(40,1,3);
ysailor=randi(40,1,3);
xcurrent=20;
ycurrent=20;
newx=0;
newy=0;
found=0;
fuel=400;
xrefuel=0;
yrefuel=0;

%building grid and placing sailors
xlabel('X Axis')
ylabel('Y Axis')
title('Missing Sailor Grid')
scatter(20,20,100,'red','filled'); % plot a circle, at x,y, size=100, red color, filled in

%randomly place mising sailors
for k=1:3
    scatter(xsailor(k),ysailor(k));
end

%Searching for sailors
while found<3
    [newx, newy] = move(xcurrent, ycurrent); %moves boat in a random direction
    %setting new points for boat after the move
    xcurrent=newx;
    ycurrent=newy;

%checking if sailor is found
    for k=1:3
        if (xcurrent==xsailor(k))&&(ycurrent==ysailor(k))
            %Print out found message
            msg = sprintf('Sailor found at x=%d y=%d',xcurrent,ycurrent);
            display(msg);
            found=found+1;
            xsailor(1,k)=[41];%set point outside the bounds so the a sailor is not found more than once
        end
    end
%Fuel increment and check
    fuel=fuel-1
    if (fuel==40)
        xrefuel=xcurrent-20; %finding distance from home base
        yrefuel=ycurrent-20; %finding distance from home base
        %plotting line from current position to home base for refueling
        color='red'
        line([xcurrent,20],[ycurrent,ycurrent],'Color',color);
        line([20,20],[ycurrent,20],'Color',color);
        %resetting boat point for refueling
        xcurrent=xcurrent-xrefuel
        ycurrent=ycurrent-yrefuel
        fuel=400 %resetting fuel used
    end
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description: This function is used as a search strategy for the robot
% boat to find all the sailors by generating a random integer between 0 and 3 and 
% moving in a direction based on the integer created.It keeps the boat on
% the grid by checking if the values are on the boundaries and not allowing
% the boat to move in a direction such that it would move off the grid.
% Inputs: xcurrent, type-int, is used to track the boat's current X position
%         ycurrent, type-int, is used to track the boat's current Y
%         position
% Outputs: newx, type-int, is returned to move the boat the next
%          corresponding X position
%          newy, type-int, is returned to move the boat to the next
%          corresponding Y position
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [newx, newy] = move(xcurrent, ycurrent)
direction=randi(4)-1; %generates random number 0-3
newx=xcurrent;
newy=ycurrent;
%series of if statements to keep the boat on the grid
if newx==0 %cannot go west
    if direction==0
        [newx,newy]=north(xcurrent,ycurrent);
    elseif direction==2
        [newx,newy]=south(xcurrent,ycurrent);
    elseif direction==3
        [newx,newy]=east(xcurrent,ycurrent);
    end
elseif newx==40 %cannot go east
    if direction==0
        [newx,newy]=north(xcurrent,ycurrent);
    elseif direction==1
        [newx,newy]=west(xcurrent,ycurrent);
    elseif direction==2
        [newx,newy]=south(xcurrent,ycurrent);
    end
elseif newy==0 %cannot go south
    if direction==0
        [newx,newy]=north(xcurrent,ycurrent);
    elseif direction==1
        [newx,newy]=west(xcurrent,ycurrent);
    elseif direction==3
        [newx,newy]=east(xcurrent,ycurrent);
    end
elseif newy==40 %cannot go north
    if direction==1
        [newx,newy]=west(xcurrent,ycurrent);
    elseif direction==2
        [newx,newy]=south(xcurrent,ycurrent);
    elseif direction==3
        [newx,newy]=east(xcurrent,ycurrent);
    end
else
    if direction==0
        [newx,newy]=north(xcurrent,ycurrent);
    elseif direction==1
        [newx,newy]=west(xcurrent,ycurrent);
    elseif direction==2
        [newx,newy]=south(xcurrent,ycurrent);
    elseif direction==3
        [newx,newy]=east(xcurrent,ycurrent);
    end
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description: This function used when the random direction generated is 3
% to move the boat one X postion East
% Inputs: xcurrent, type-int, is used to determine where the boat moves
%         from in the X position
%         ycurrent, type-int, is used to determine where the boat moves
%         from in the Y position
% Outputs: newx, type-int, is used to return the new X position to search
%          for the sailors
%          newy, type-int, is used to return the new Y position to search
%          for the sailors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [newx,newy]=east(xcurrent,ycurrent)
     newx=xcurrent+1;
     newy=ycurrent;
     color = 'green';
     line([xcurrent,newx],[ycurrent,newy],'Color',color);
     pause(0.001)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description: This function used when the random direction generated is 0
% to move the boat one Y postion North
% Inputs: xcurrent, type-int, is used to determine where the boat moves
%         from in the X position
%         ycurrent, type-int, is used to determine where the boat moves
%         from in the Y position
% Outputs: newx, type-int, is used to return the new X position to search
%          for the sailors
%          newy, type-int, is used to return the new Y position to search
%          for the sailors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [newx,newy]=north(xcurrent,ycurrent)
     newy=ycurrent+1;
     newx=xcurrent;
     color = 'green';
     line([xcurrent,newx],[ycurrent,newy],'Color',color);
     pause(0.001)
end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description: This function used when the random direction generated is 1
% to move the boat one X postion West
% Inputs: xcurrent, type-int, is used to determine where the boat moves
%         from in the X position
%         ycurrent, type-int, is used to determine where the boat moves
%         from in the Y position
% Outputs: newx, type-int, is used to return the new X position to search
%          for the sailors
%          newy, type-int, is used to return the new Y position to search
%          for the sailors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
function [newx,newy]=west(xcurrent,ycurrent)
     newx=xcurrent-1;
     newy=ycurrent;
     color = 'green';
     line([xcurrent,newx],[ycurrent,newy],'Color',color);
     pause(0.001)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description: This function used when the random direction generated is 3
% to move the boat one Y postion South
% Inputs: xcurrent, type-int, is used to determine where the boat moves
%         from in the X position
%         ycurrent, type-int, is used to determine where the boat moves
%         from in the Y position
% Outputs: newx, type-int, is used to return the new X position to search
%          for the sailors
%          newy, type-int, is used to return the new Y position to search
%          for the sailors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [newx,newy]=south(xcurrent,ycurrent)
     newy=ycurrent-1;
     newx=xcurrent;
     color = 'green';
     line([xcurrent,newx],[ycurrent,newy],'Color',color);
     pause(0.001)
end