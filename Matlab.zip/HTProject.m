%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Name: Gabriel Behrendt
%   Date: April 29,2019
%   Program Name: HTProject.m
%   Program Description: This program simulates a heat sink that dissipates
%   at least 350 W as fluid flows over the sink
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear, clc

%Paraemters that I choose
    D=3/100;     %Diameter of pins (m)
    Sl=25/600;          %Horizontal distance between center of pins (m)
    St=25/600;          %Vertical distance between center of pins (m)
    finh=79/1000;       %height of fins (m)
    baseh=20/1000;      %height of fin base (m)
    Sd = sqrt(Sl^2 + (St^2)/2); %Diagnol distance between centers of pins (m)
    N=25;               %Number of pins
    Nt=5;               %Number of pins per row
    
%Given Values
    V = 3;    %velocity of air over plate (m/s)
    L=25/100; %size of motor plate (m)
    Ts=80;     %Surface Temp (Celcius)
    Tinf=18;   %air temp (Celcius)
    
%Air properties at T(inf)=291K
    p=1.213;          %density (kg/m^3)
    cp=1006;          %specific heat (J/kg*K)
    v=1.4929*10^-5;   %kinematic viscosity (m^2/s)
    kair=0.025445;    %thermal conductivity (W/m*K)
    Pr=0.71598;       %Prandtl number

%Find Reynolds Number
    %Checking to see which Vmax equation to use
    left = (2*(Sd-D));
    right = St-D;
    
    Vmax=(St*V)/(St-D);
    RedMax=D*Vmax/v;
    
%Correlation Equation (finding c1 and c2)
    %check correlation condition
    corr=St/Sl;
    
    c1=0.35*(St/Sl)^(1/5);
    m=0.6;
    c2=0.92;
    
%Checking sink base temp
    qcond=200;                              %test value for heat from conduction
    k1=152;                                 %thermal conductivity of aluminum 6061
    Tsinkbase=((qcond*baseh/(k1*L^2))-Ts)*-1;
    %The change in temperature in the sink base is less than 5% of the
    %motor surface temperature so q conduction is negligible
   
    
%Calculating h
    Prs=0.70674;
    Nubar=c1*c2*(RedMax^m)*(Pr^0.36)*(Pr/Prs)^0.25;
    hbar=Nubar*kair/D;
    
%Calculating q
    deltaT=(Ts-Tinf)*exp(-(pi*D*N*hbar)/(p*V*Nt*St*cp));
    deltaTlm=((Ts-Tinf)-deltaT)/log((Ts-Tinf)/deltaT);
    qprime=N*hbar*pi*D*deltaTlm;
    q=qprime*finh

%Plot fin height vs heat dissipated
    fin=(.01:.0008:.09); %Meters
    finmm=fin*1000;     %Millimeters
    qpoints=qprime*fin;
    figure(1)
    plot(finmm,qpoints,'g')
    axis([0 100 50 1200]);
    xlabel('Fin height (mm)');
    ylabel('Heat Dissipated (W)');
    title('Heat Dissipation for Varying Fin Heights');
    
%Plotting Diameter vs heat dissipated
    diam = (0.5:0.1:4)/100;
    diam100=(0.5:0.1:4);
    qmat = zeros(1,36);
    for n=1:36
        Vmax=(St*V)/(St-diam(n));
        RedMax=diam(n)*Vmax/v;
        hbar=Nubar*kair/diam(n);
        deltaT=(Ts-Tinf)*exp(-(pi*diam(n)*N*hbar)/(p*V*Nt*St*cp));
        deltaTlm=((Ts-Tinf)-deltaT)/log((Ts-Tinf)/deltaT);
        qprime=N*hbar*pi*diam(n)*deltaTlm;
        qnew=qprime*finh;
        qmat(n)=qnew;
    end
    figure(2)
    plot(diam100,qmat)
    axis([0 4.5 800 1200]);
    xlabel('Fin Diameter (m)');
    ylabel('Heat Dissipated (W)');
    title('Heat Dissipation for Varying Fin Diameters');
    
%Resistance Calculation
    R2=(Ts-Tinf)/q;
    R2primex2=R2*L^2;
