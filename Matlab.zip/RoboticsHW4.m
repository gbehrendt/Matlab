%Problem 1
q = [-2;1;0];
shat = [0;0;1];
theta = 5;
shattheta = shat*theta;
A=cross(-shattheta,q);

%Problem 2
s=[pi/4;pi/6;pi/6];
q=[1;3;5];
h=5;
theta=pi/6;
hst=h*s*theta;
stq=cross(s*theta,q);
v=hst-stq; %linear velocity
w=s*theta; %angular velocity
wbrack=[0,-w(3,1),w(2,1);w(3,1),0,-w(1,1);-w(2,1),w(1,1),0]; %omega bracket

%calculating star
A=eye(3)*theta;
B=(1-cos(theta))*wbrack;
C=(theta-sin(theta))*(wbrack^2);
star=(A+B+C)*v;

%calculating e^[w]*theta
D=eye(3)+(sin(theta)*wbrack);
E=(1-cos(theta))*(wbrack^2);
matrixexp1=D+E;

%calculating e^[S]*theta
matrixexp2=[matrixexp1,star;0, 0, 0, 1]

%Problem 3
tx=pi/3;
ty=pi/4;
Rx=[1,0,0;0,cos(tx),sin(tx);0,sin(tx),cos(tx)];
Ry=[cos(ty),0,sin(ty);0,1,0;-sin(ty),0,cos(ty)];
R=Rx*Ry; %Rotation Matrix
p=[1;5;1]; %translation
Tsa=[1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1]; %Tsa=Tsainverse
Tsaprime=[R,p;0 0 0 1];
eSTheta=Tsa*Tsaprime;
Sbrack_theta=logm(eSTheta) %%Imaginary Numbers????
omega = [Sbrack_theta(3,2); Sbrack_theta(1,3); Sbrack_theta(2,1)]; %angular velocity
theta = norm(omega); %distance travelled
omega_hat = omega/theta; %Normalized angular velocity
v = Sbrack_theta(1:3,4); %velocity
v_hat = v/theta; %normalized velocity
S = [ omega_hat; v_hat ] % because S is defind as the normalized screw axis

h = (transpose(omega_hat)*v)/norm(omega); %Pitch



