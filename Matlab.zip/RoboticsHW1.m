clear all; close all; clc;

%Problem 2 Part h
omegatheta = [1;2;0];
theta = norm(omegatheta);
omegahat = [1;2;0]/theta
omegahatbrack=[0 0 omegahat(2,1); 0 0 -omegahat(1,1);-omegahat(2,1) omegahat(1,1) 0]

R1=eye(3)+(sin(theta)*omegahatbrack)+((1-cos(theta))*(omegahatbrack^2))

R2=expm(omegahatbrack*theta)